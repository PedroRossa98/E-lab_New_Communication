
env = {
  IP: '192.168.1.81',  
  USER: 'yourname',
  HOSTNAME: 'ubuntu'
}

